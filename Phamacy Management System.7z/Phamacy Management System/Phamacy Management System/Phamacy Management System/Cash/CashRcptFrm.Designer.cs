﻿namespace Phamacy_Management_System
{
    partial class CashRcptFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.recptNolbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.rcptDatelbl = new System.Windows.Forms.Label();
            this.rcptEmpNametxt = new System.Windows.Forms.TextBox();
            this.rcptDebtNametxt = new System.Windows.Forms.TextBox();
            this.rcptPaytxt = new System.Windows.Forms.TextBox();
            this.rcptPendtxt = new System.Windows.Forms.TextBox();
            this.rcptMaxDebttxt = new System.Windows.Forms.TextBox();
            this.rcptSavebtn = new System.Windows.Forms.Button();
            this.rcptCanclebtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.rcptDebtorPaymenttxt = new System.Windows.Forms.TextBox();
            this.rcptEmpIdtxt = new System.Windows.Forms.TextBox();
            this.rcptDebtIdtxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(274, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Receipt no.";
            // 
            // recptNolbl
            // 
            this.recptNolbl.AutoSize = true;
            this.recptNolbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recptNolbl.ForeColor = System.Drawing.Color.SkyBlue;
            this.recptNolbl.Location = new System.Drawing.Point(349, 13);
            this.recptNolbl.Name = "recptNolbl";
            this.recptNolbl.Size = new System.Drawing.Size(80, 16);
            this.recptNolbl.TabIndex = 1;
            this.recptNolbl.Text = "recptNolbl";
            this.recptNolbl.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(22, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Receipting Employee";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(22, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Debtor";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(22, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Payment";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(22, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Pending";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(24, 246);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Max Debt";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(498, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Date";
            // 
            // rcptDatelbl
            // 
            this.rcptDatelbl.AutoSize = true;
            this.rcptDatelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptDatelbl.ForeColor = System.Drawing.Color.SkyBlue;
            this.rcptDatelbl.Location = new System.Drawing.Point(539, 59);
            this.rcptDatelbl.Name = "rcptDatelbl";
            this.rcptDatelbl.Size = new System.Drawing.Size(84, 16);
            this.rcptDatelbl.TabIndex = 8;
            this.rcptDatelbl.Text = "rcptDatelbl";
            // 
            // rcptEmpNametxt
            // 
            this.rcptEmpNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptEmpNametxt.ForeColor = System.Drawing.Color.SkyBlue;
            this.rcptEmpNametxt.Location = new System.Drawing.Point(164, 56);
            this.rcptEmpNametxt.Name = "rcptEmpNametxt";
            this.rcptEmpNametxt.ReadOnly = true;
            this.rcptEmpNametxt.Size = new System.Drawing.Size(228, 22);
            this.rcptEmpNametxt.TabIndex = 9;
            // 
            // rcptDebtNametxt
            // 
            this.rcptDebtNametxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.rcptDebtNametxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.rcptDebtNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptDebtNametxt.ForeColor = System.Drawing.Color.SkyBlue;
            this.rcptDebtNametxt.Location = new System.Drawing.Point(146, 114);
            this.rcptDebtNametxt.Name = "rcptDebtNametxt";
            this.rcptDebtNametxt.Size = new System.Drawing.Size(257, 22);
            this.rcptDebtNametxt.TabIndex = 0;
            this.rcptDebtNametxt.TextChanged += new System.EventHandler(this.saveBtnValidating);
            this.rcptDebtNametxt.Validating += new System.ComponentModel.CancelEventHandler(this.textBox2_Validating);
            // 
            // rcptPaytxt
            // 
            this.rcptPaytxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptPaytxt.ForeColor = System.Drawing.Color.SkyBlue;
            this.rcptPaytxt.Location = new System.Drawing.Point(146, 157);
            this.rcptPaytxt.Name = "rcptPaytxt";
            this.rcptPaytxt.Size = new System.Drawing.Size(257, 22);
            this.rcptPaytxt.TabIndex = 1;
            this.rcptPaytxt.TextChanged += new System.EventHandler(this.saveBtnValidating);
            // 
            // rcptPendtxt
            // 
            this.rcptPendtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptPendtxt.ForeColor = System.Drawing.Color.SkyBlue;
            this.rcptPendtxt.Location = new System.Drawing.Point(146, 200);
            this.rcptPendtxt.Name = "rcptPendtxt";
            this.rcptPendtxt.Size = new System.Drawing.Size(257, 22);
            this.rcptPendtxt.TabIndex = 2;
            this.rcptPendtxt.TextChanged += new System.EventHandler(this.saveBtnValidating);
            // 
            // rcptMaxDebttxt
            // 
            this.rcptMaxDebttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptMaxDebttxt.ForeColor = System.Drawing.Color.SkyBlue;
            this.rcptMaxDebttxt.Location = new System.Drawing.Point(146, 239);
            this.rcptMaxDebttxt.Name = "rcptMaxDebttxt";
            this.rcptMaxDebttxt.Size = new System.Drawing.Size(257, 22);
            this.rcptMaxDebttxt.TabIndex = 3;
            this.rcptMaxDebttxt.TextChanged += new System.EventHandler(this.saveBtnValidating);
            // 
            // rcptSavebtn
            // 
            this.rcptSavebtn.BackColor = System.Drawing.Color.Teal;
            this.rcptSavebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptSavebtn.ForeColor = System.Drawing.Color.White;
            this.rcptSavebtn.Location = new System.Drawing.Point(244, 322);
            this.rcptSavebtn.Name = "rcptSavebtn";
            this.rcptSavebtn.Size = new System.Drawing.Size(95, 35);
            this.rcptSavebtn.TabIndex = 4;
            this.rcptSavebtn.Text = "Save";
            this.rcptSavebtn.UseVisualStyleBackColor = false;
            this.rcptSavebtn.Click += new System.EventHandler(this.rcptSavebtn_Click);
            // 
            // rcptCanclebtn
            // 
            this.rcptCanclebtn.BackColor = System.Drawing.Color.Teal;
            this.rcptCanclebtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.rcptCanclebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptCanclebtn.ForeColor = System.Drawing.Color.White;
            this.rcptCanclebtn.Location = new System.Drawing.Point(372, 322);
            this.rcptCanclebtn.Name = "rcptCanclebtn";
            this.rcptCanclebtn.Size = new System.Drawing.Size(95, 35);
            this.rcptCanclebtn.TabIndex = 5;
            this.rcptCanclebtn.Text = "Cancle";
            this.rcptCanclebtn.UseVisualStyleBackColor = false;
            this.rcptCanclebtn.Click += new System.EventHandler(this.rcptCanclebtn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(24, 282);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 16);
            this.label9.TabIndex = 10;
            this.label9.Text = "Debtor Payment";
            // 
            // rcptDebtorPaymenttxt
            // 
            this.rcptDebtorPaymenttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptDebtorPaymenttxt.ForeColor = System.Drawing.Color.SkyBlue;
            this.rcptDebtorPaymenttxt.Location = new System.Drawing.Point(146, 281);
            this.rcptDebtorPaymenttxt.Name = "rcptDebtorPaymenttxt";
            this.rcptDebtorPaymenttxt.Size = new System.Drawing.Size(257, 22);
            this.rcptDebtorPaymenttxt.TabIndex = 11;
            this.rcptDebtorPaymenttxt.TextChanged += new System.EventHandler(this.saveBtnValidating);
            // 
            // rcptEmpIdtxt
            // 
            this.rcptEmpIdtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptEmpIdtxt.Location = new System.Drawing.Point(396, 55);
            this.rcptEmpIdtxt.Name = "rcptEmpIdtxt";
            this.rcptEmpIdtxt.ReadOnly = true;
            this.rcptEmpIdtxt.Size = new System.Drawing.Size(50, 22);
            this.rcptEmpIdtxt.TabIndex = 12;
            // 
            // rcptDebtIdtxt
            // 
            this.rcptDebtIdtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rcptDebtIdtxt.Location = new System.Drawing.Point(408, 114);
            this.rcptDebtIdtxt.Name = "rcptDebtIdtxt";
            this.rcptDebtIdtxt.ReadOnly = true;
            this.rcptDebtIdtxt.Size = new System.Drawing.Size(50, 22);
            this.rcptDebtIdtxt.TabIndex = 13;
            // 
            // CashRcptFrm
            // 
            this.AcceptButton = this.rcptSavebtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.CancelButton = this.rcptCanclebtn;
            this.ClientSize = new System.Drawing.Size(712, 364);
            this.Controls.Add(this.rcptDebtIdtxt);
            this.Controls.Add(this.rcptEmpIdtxt);
            this.Controls.Add(this.rcptDebtorPaymenttxt);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.rcptCanclebtn);
            this.Controls.Add(this.rcptSavebtn);
            this.Controls.Add(this.rcptMaxDebttxt);
            this.Controls.Add(this.rcptPendtxt);
            this.Controls.Add(this.rcptPaytxt);
            this.Controls.Add(this.rcptDebtNametxt);
            this.Controls.Add(this.rcptEmpNametxt);
            this.Controls.Add(this.rcptDatelbl);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.recptNolbl);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "CashRcptFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cash Receipt";
            this.Load += new System.EventHandler(this.CashRcptFrm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label recptNolbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label rcptDatelbl;
        private System.Windows.Forms.TextBox rcptEmpNametxt;
        private System.Windows.Forms.TextBox rcptDebtNametxt;
        private System.Windows.Forms.TextBox rcptPaytxt;
        private System.Windows.Forms.TextBox rcptPendtxt;
        private System.Windows.Forms.TextBox rcptMaxDebttxt;
        private System.Windows.Forms.Button rcptSavebtn;
        private System.Windows.Forms.Button rcptCanclebtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox rcptDebtorPaymenttxt;
        private System.Windows.Forms.TextBox rcptEmpIdtxt;
        private System.Windows.Forms.TextBox rcptDebtIdtxt;
    }
}