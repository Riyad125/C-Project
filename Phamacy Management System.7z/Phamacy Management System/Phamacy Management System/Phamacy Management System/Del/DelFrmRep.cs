﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phamacy_Management_System.Del
{
    public partial class DelFrmRep : Form
    {
        public DelFrmRep()
        {
            InitializeComponent();
        }

        private void DelRep1_InitReport(object sender, EventArgs e)
        {

        }
    }
}
