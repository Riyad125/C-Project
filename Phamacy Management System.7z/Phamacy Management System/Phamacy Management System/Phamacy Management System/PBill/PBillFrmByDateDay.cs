﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Phamacy_Management_System
{
    public partial class PBillFrmByDateDay : Form
    {
        SqlConnection cn = new SqlConnection("server=. ; database=pharmacy ; integrated security=true");

        public PBillFrmByDateDay()
        {
            InitializeComponent();
        }

        private void PBillFrmByDateDay_Load(object sender, EventArgs e)
        {

          //  string startdate.ToString("MM/dd/yyyy 23:59:59.999") = ComDateFrom.Text;

           // string enddate = DateTime.Now.ToString("MM/dd/yyyy 23:59:59.999");

            //      SqlCommand cm1 = new SqlCommand("select pBillDate from pBill", cn);
          


          SqlCommand cm1 = new SqlCommand("select pBillDate from pBill", cn);

            cn.Open();
            SqlDataReader dr1 = cm1.ExecuteReader();
            while (dr1.Read())
            {
                ComDateFrom.Items.Add(dr1["pBillDate"]);

            }
            cn.Close();


            SqlCommand cm2 = new SqlCommand("select pBillDate from pBill", cn);
            cn.Open();
            SqlDataReader dr2 = cm1.ExecuteReader();
            while (dr2.Read())
            {
                ComDateTo.Items.Add(dr2["pBillDate"]);

            }
            cn.Close();


            




        }

        private void ComDateFrom_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnsearch_Click(object sender, EventArgs e)
        {

           // string startdate = Convert.ToString(ComDateFrom.SelectedItem);
            //string enddate = Convert.ToString(ComDateTo.SelectedItem);

            

        //    string aden = ComDateFrom.SelectedItem.ToString("M/dd/yyyy");




            SqlDataAdapter da9 = new SqlDataAdapter("SELECT pBill.pBillNo, pBill.pBillDate, pBill.compName, pBill.delName,pBill.empname,pBill.ttlcost, pBillDet.itmBar, item.itmTrdName, pBillDet.itmUnit, pBillDet.exdate,pBillDet.quant, pBillDet.ttlPrice FROM  item INNER JOIN pBillDet ON item.itmBar = pBillDet.itmBar INNER JOIN pBill ON pBillDet.pBillNo = pBill.pBillNo WHERE pBill.pBillDate between '" + ComDateFrom.SelectedItem + "' AND '" + ComDateTo.SelectedItem + "'  ", cn);
            DataSet ds9 = new DataSet();
            da9.Fill(ds9, "item,pBillDet,pBill");

            PBill.PBillByNo obj = new PBill.PBillByNo();
            obj.SetDataSource(ds9.Tables["item,pBillDet,pBill"]);

            crystalReportViewer1.ReportSource = obj;


     //  textBox1.Text = Convert.ToString(ComDateTo.SelectedItem);
          //  textBox1.Text = ComDateTo.SelectedItem.ToString();
        }
    }
}
