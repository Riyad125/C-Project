﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Phamacy_Management_System
{
    public partial class PBillFrm : Form
    {
        SqlConnection cn = new SqlConnection("server=. ; database=pharmacy ; integrated security=true");
        SqlCommand cmd;
        SqlDataAdapter da;

        SqlDataAdapter da2;
        SqlDataReader dr;
        SqlDataReader dr2;

        DataTable dt = new DataTable();
        DataTable dt2 = new DataTable();
        DataTable dt3 = new DataTable();

        SqlDataAdapter da4;
        SqlDataReader dr4;
        DataTable dt4 = new DataTable();
        SqlDataAdapter da5;
        SqlDataReader dr5;
        DataTable dt5 = new DataTable();

        SqlDataAdapter da6;
        SqlDataReader dr6;
        DataTable dt6 = new DataTable();

        string scompid;
        string sdelid;
        string coco;



        int packet = 0;
        int table = 0;
        int pill = 0;
        int piece = 0;
        double packBP = 0.0;
        double tabBP = 0.0;
        double pillBP = 0.0;
        double pieceBP = 0.0;
        double packQuant = 0.0;
        double tabQuant = 0.0;
        double pillQuant = 0;
        double pieceQuant = 0;
        public PBillFrm()
        {
            InitializeComponent();
            pBillSavebtn.Enabled = false;

            PBillCompNamecmbo.SelectedIndexChanged -= PBillCompNamecmbo_SelectedIndexChanged;

            da4 = new SqlDataAdapter("select compId,compName from comp", cn);
            da4.Fill(dt4);
            PBillCompNamecmbo.DataSource = dt4;
            PBillCompNamecmbo.DisplayMember = "compName";
            PBillCompNamecmbo.ValueMember = "compId";


         





      

           

            PBillCompNamecmbo.SelectedIndexChanged += PBillCompNamecmbo_SelectedIndexChanged;

            //cn.Open();
            //cmd = new SqlCommand("select empname from emp where empid = ( select  max(empid)  from emplogin ) ", cn);
            //dr = cmd.ExecuteReader();
            //pBillEmpNametxt.Text = dr["empname"].ToString();
       //string empid;
            //while (dr.Read())
            //{

             //   empid = dr["empid"].ToString();


               
            //}
       
            // dr.Close();
            //cn.Close();







        //   da5 = new SqlDataAdapter("select empid  from emplogin", cn);

            da5 = new SqlDataAdapter(" select empname,empid from emp where empid = ( select  min(empid)  from emplogin )", cn);
            da5.Fill(dt5);
            pBillEmpNametxt.Text = dt5.Rows[0]["empname"].ToString();
            pBillEmpIDtxt.Text = dt5.Rows[0]["empid"].ToString();





         

          
      //      cmd = new SqlCommand("select empname from emp where empid='"+ pBillEmpNametxt.Text + "'" , cn);


      //cn.Open();
      //      dr = cmd.ExecuteReader();
      //      dr.Read();
      //      empname = (dr["empname"].ToString());

      //      cn.Close();
            //table = Convert.ToInt32(dr["tab"].ToString());
            //pill = Convert.ToInt32(dr["pill"].ToString());
            //piece = Convert.ToInt32(dr["piece"].ToString());




            //            this.pBillAddItembtn.Enabled = false;
            // this.pBillSavebtn.Enabled = false;
            createDataTable();
          unitItemsAdd();

           

        }
        int selectrow;

  
        void calcTotalPrice()
        {
            itemTtlPricetxt.Text = (Convert.ToInt32(itemQuanttxt.Text) * Convert.ToDouble(itemPricetxt.Text)).ToString();
        }

        void validateAddItembtn()
        {
            this.pBillAddItembtn.Enabled = ((pBillItemBartxt.Text.Length != 0) && (itemQuanttxt.Text.Length != 0) && (itemPricetxt.Text.Length != 0)) || ((pBillItemNametxt.Text.Length != 0) && (itemQuanttxt.Text.Length != 0) && (itemPricetxt.Text.Length != 0));
        }
        void unitItemsAdd()
        {


            itemUnitcmbo.Items.Add("Packet");
            itemUnitcmbo.Items.Add("Table");
            itemUnitcmbo.Items.Add("Pill");
            itemUnitcmbo.Items.Add("Piece");
        }
        void createDataTable()
        {
            dt.Columns.Add("ITEM BARCODE");
            dt.Columns.Add("ITEM NAME");
            dt.Columns.Add("UNIT");
            dt.Columns.Add("EXPIRY DATE");
            dt.Columns.Add("QUANTITY");
            dt.Columns.Add("PRICE");
            dt.Columns.Add("TOTAL PRICE");
            dt.Columns.Add("packBuy");
            dt.Columns.Add("tabBuy");
            dt.Columns.Add("pillBuy");
            dt.Columns.Add("pieceBuy");
            dt.Columns.Add("packQuant");
            dt.Columns.Add("tabQuant");
            dt.Columns.Add("pillQuant");
            dt.Columns.Add("pieceQuant");
            pBilldgv.DataSource = dt;
        }

        void readValuesOfUnits()
        {
            try
            {
                cmd = new SqlCommand("select pack,tab,pill,piece from item where itmTrdName='" + pBillItemNametxt.Text + "' or itmBar='" + pBillItemBartxt.Text + "'", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
                packet = Convert.ToInt32(dr["pack"].ToString());
                table = Convert.ToInt32(dr["tab"].ToString());
                pill = Convert.ToInt32(dr["pill"].ToString());
                piece = Convert.ToInt32(dr["piece"].ToString());
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                cn.Open();
            }
        }

        void clearItemsText()
        {
            pBillItemBartxt.Clear();
            pBillItemNametxt.Clear();
            itemUnitcmbo.SelectedItem = -1;
            itemQuanttxt.Clear();
            itemPricetxt.Clear();
            itemTtlPricetxt.Clear();
        }
        private void pBilldgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



        }

        private void PBillFrm_Load(object sender, EventArgs e)
        {
            try
            {

                

                pBilldgv.Columns["packBuy"].Visible = false;
                pBilldgv.Columns["tabBuy"].Visible = false;
                pBilldgv.Columns["pillBuy"].Visible = false;
                pBilldgv.Columns["pieceBuy"].Visible = false;
                pBilldgv.Columns["packQuant"].Visible = false;
                pBilldgv.Columns["tabQuant"].Visible = false;
                pBilldgv.Columns["pillQuant"].Visible = false;
                pBilldgv.Columns["pieceQuant"].Visible = false;


               

                AutoCompleteStringCollection LocalDataTable = new AutoCompleteStringCollection();

                pBillItemBartxt.AutoCompleteMode = AutoCompleteMode.SuggestAppend;

                pBillItemBartxt.AutoCompleteSource = AutoCompleteSource.CustomSource;

                pBillItemBartxt.AutoCompleteCustomSource = LocalDataTable;


               cn.Open();
                SqlCommand cmd = new SqlCommand("select itmbar from item", cn);

                SqlDataReader rd2 = cmd.ExecuteReader();

                if (rd2.HasRows == true)
                {

                    while (rd2.Read())
                    {

                        LocalDataTable.Add(rd2[0].ToString());

                    }

                }

                cn.Close();




                pBillItemNametxt.AutoCompleteMode = AutoCompleteMode.SuggestAppend;

                pBillItemNametxt.AutoCompleteSource = AutoCompleteSource.CustomSource;

                pBillItemNametxt.AutoCompleteCustomSource = LocalDataTable;


                cn.Open();
                SqlCommand cmd3 = new SqlCommand("select itmtrdname from item", cn);

                SqlDataReader rd3 = cmd3.ExecuteReader();

                if (rd3.HasRows == true)
                {

                    while (rd3.Read())
                    {

                        LocalDataTable.Add(rd3[0].ToString());

                    }

                }

                cn.Close();


            //    pBillDatelbl.Text = DateTime.Now.ToString();
            //    pBillDatelbl.Text = DateTime.Now.ToString("dd/MM/yyyy");




               //var someVar = DateTime.Now;
               //pBillDatelbl.Text = someVar.ToString("dd/MM/yyyy");

               pBillDatelbl.Text = DateTime.Now.ToString("MM/dd/yyyy H:mm:ss");

            //   pBillDatelbl.Text = DateTime.Now.ToString("M/dd/yyyy");

               // string someVar = pBillDatelbl.Text;

               // pBillDatelbl.Text = someVar.ToShortDateString();

             //   coco = DateTime.Now.ToString("dd/MM/yyyy");
          //     pBillDatelbl.Text = Convert.ToString(coco);
               cmd = new SqlCommand("SELECT COALESCE(max(pBillNo),0) AS pBillNo from pBill", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                dr.Read();
              pBillNolbl.Text = Convert.ToString ( Convert.ToInt32( dr["pBillNo"] )+1 ); 
                dr.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

                cn.Close();
            }


        }

        private void pBillDelNamecmbo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pBilldgv_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pBillAddItembtn_Click(object sender, EventArgs e)
        {
            
            string aden = itemExdatedtp.Value.ToString("M/dd/yyyy");

            cmd = new SqlCommand("select pack,tab,pill,piece from item where itmbar='" + pBillItemBartxt.Text + "'", cn);

            cn.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            string pack;
            string tab;
            string pill;
            string piece;



            pack = dr["pack"].ToString();
            tab = dr["tab"].ToString();
            pill = dr["pill"].ToString();
            piece = dr["piece"].ToString();

            dr.Close();
            cn.Close();

            pBillItemNametxt.ReadOnly = false;
            pBillItemBartxt.ReadOnly = false;

            if (itemUnitcmbo.SelectedIndex == 0)
            {


                packBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pack)) / Convert.ToDouble(pack);
                tabBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(tab)) / Convert.ToDouble(pack);
                pillBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pill)) / Convert.ToDouble(pack);

                packQuant = (Convert.ToDouble(pack) / Convert.ToDouble(pack)) * Convert.ToInt32(itemQuanttxt.Text);
                tabQuant = (Convert.ToDouble(pack) / Convert.ToDouble(tab)) * Convert.ToInt32(itemQuanttxt.Text);
                pillQuant = (Convert.ToDouble(pack) / Convert.ToDouble(pill)) * Convert.ToInt32(itemQuanttxt.Text);


            }

            else if (itemUnitcmbo.SelectedIndex == 1)
            {


                packBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pack)) / Convert.ToDouble(tab);
                tabBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(tab)) / Convert.ToDouble(tab);
                pillBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pill)) / Convert.ToDouble(tab);

                packQuant = (Convert.ToDouble(tab) / Convert.ToDouble(pack)) * Convert.ToInt32(itemQuanttxt.Text);
                tabQuant = (Convert.ToDouble(tab) / Convert.ToDouble(tab)) * Convert.ToInt32(itemQuanttxt.Text);
                pillQuant = (Convert.ToDouble(tab) / Convert.ToDouble(pill)) * Convert.ToInt32(itemQuanttxt.Text);


            }

            else if (itemUnitcmbo.SelectedIndex == 2)
            {


                packBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pack)) / Convert.ToDouble(pill);
                tabBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(tab)) / Convert.ToDouble(pill);
                pillBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pill)) / Convert.ToDouble(pill);

                packQuant = (Convert.ToDouble(pill) / Convert.ToDouble(pack)) * Convert.ToInt32(itemQuanttxt.Text);
                tabQuant = (Convert.ToDouble(pill) / Convert.ToDouble(tab)) * Convert.ToInt32(itemQuanttxt.Text);
                pillQuant = (Convert.ToDouble(pill) / Convert.ToDouble(pill)) * Convert.ToInt32(itemQuanttxt.Text);


            }
            else if (itemUnitcmbo.SelectedIndex == 3)
            {
                pieceBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(piece)) / Convert.ToDouble(piece);

                pieceQuant = (Convert.ToDouble(piece) * Convert.ToInt32(itemQuanttxt.Text));


            }





            DataRow r = dt.NewRow();
            r[0] = pBillItemBartxt.Text;
            r[1] = pBillItemNametxt.Text;
            r[2] = itemUnitcmbo.SelectedItem;

            r[3] = aden;

            r[4] = itemQuanttxt.Text;
            r[5] = itemPricetxt.Text;
            r[6] = itemTtlPricetxt.Text;
            r[7] = packBP;
            r[8] = tabBP;
            r[9] = pillBP;
            r[10] = pieceBP;
            r[11] = packQuant;
            r[12] = tabQuant;
            r[13] = pillQuant;
            r[14] = pieceQuant;


            dt.Rows.Add(r);
            pBilldgv.DataSource = dt;
            clearItemsText();
            pBillTtlCostlbl.Text = (from DataGridViewRow row in pBilldgv.Rows where row.Cells[6].FormattedValue.ToString() != string.Empty select Convert.ToDouble(row.Cells[6].FormattedValue)).Sum().ToString();
        }

        private void addItemTextvalidating(object sender, EventArgs e)
        {

        }

        private void pBilldgv_Validating(object sender, CancelEventArgs e)
        {

        }

        private void addItemTextvalidating(object sender, CancelEventArgs e)
        {

        }

        private void addItemValidating(object sender, CancelEventArgs e)
        {
            validateAddItembtn();

        }

        private void calcTotalPriceOnFocus(object sender, EventArgs e)
        {
            if (itemQuanttxt.Text.Length != 0 && itemPricetxt.Text.Length != 0)
            {
                calcTotalPrice();
            }
            else
            {
                itemTtlPricetxt.Clear();
            }
        }

        private void pBillSavebtn_Click(object sender, EventArgs e)
        {

            try
            {
       //  string dataofpbill;
      //   dataofpbill = pBillDatelbl.Text;
         //       string date = pBillDatelbl.Text;
      

              
                cn.Open();

                SqlCommand cmd = new SqlCommand("SET IDENTITY_INSERT pbill oN insert into pBill ( pBillNo, pBillDate, empId, empName, compId, compName, delId, delName, ttlCost) values (" + pBillNolbl.Text + ",'" + pBillDatelbl.Text + "'," + pBillEmpIDtxt.Text + " ,'" + pBillEmpNametxt.Text + "'," + scompid + ",'" + PBillCompNamecmbo.Text + "'," + sdelid + ",'" + pBillDelNamecmbo.Text + "'," + pBillTtlCostlbl.Text + ")", cn);
              //  SqlCommand cmd = new SqlCommand("insert into pBill ( pBillNo,delPBillNo, pBillDate, empId, empName, compId, compName, delId, delName, ttlCost) values (" + pBillNolbl.Text + "," + pBillDelBillNotxt.Text + ",'" + DateTime.Now + "'," + pBillEmpIDtxt.Text + " ,'" + pBillEmpNametxt.Text + "'," + scompid + ",'" + PBillCompNamecmbo.Text + "'," + sdelid + ",'" + pBillDelNamecmbo.Text + "'," + pBillTtlCostlbl.Text + ")", cn);
            //    SqlCommand cmd = new SqlCommand("SET IDENTITY_INSERT pbill oN insert into pBill ( pBillNo, pBillDate, empId, empName, compId, compName, delId, delName, ttlCost) values (" + pBillNolbl.Text + ",'2016-10-5'," + pBillEmpNametxt.Text + ",1,'AA33',3,'AMGAD',10000)", cn);

                cmd.ExecuteNonQuery();

             //   cn.Close();
                for (int i = 0; i < pBilldgv.Rows.Count; i++)


                {








                    cmd = new SqlCommand("insert into pbilldet( pBillNo, itmBar, itmUnit, itmPrice, quant, ttlPrice, exdate) values ( " + pBillNolbl.Text + ", " + pBilldgv.Rows[i].Cells["Item Barcode"].Value.ToString() + ",'" + pBilldgv.Rows[i].Cells["Unit"].Value.ToString() + "'," + pBilldgv.Rows[i].Cells["Price"].Value.ToString() + "," + pBilldgv.Rows[i].Cells["Quantity"].Value.ToString() + "," + pBilldgv.Rows[i].Cells["Total Price"].Value.ToString() + ",'" + pBilldgv.Rows[i].Cells["EXPIRY DATE"].Value.ToString() + "')", cn);
                    cmd.ExecuteNonQuery();



                    cmd = new SqlCommand("select  packQuant, tabQuant, pieceQuant, pillQuant from item where itmbar= " + pBilldgv.Rows[i].Cells["Item Barcode"].Value.ToString() + " ", cn);

                    cmd = new SqlCommand("update item set   packQuant= ( packQuant) +   " + pBilldgv.Rows[i].Cells["packQuant"].Value.ToString() + " , tabQuant= ( tabQuant) +   " + pBilldgv.Rows[i].Cells["tabQuant"].Value.ToString() + ", pillQuant= ( pillQuant) +   " + pBilldgv.Rows[i].Cells["pillQuant"].Value.ToString() + ", pieceQuant= ( pieceQuant) +   " + pBilldgv.Rows[i].Cells["pieceQuant"].Value.ToString() + ", packBP=   " + pBilldgv.Rows[i].Cells["packBuy"].Value.ToString() + " ,tabBP=   " + pBilldgv.Rows[i].Cells["tabBuy"].Value.ToString() + ",pillBP=   " + pBilldgv.Rows[i].Cells["pillBuy"].Value.ToString() + ", pieceBP=   " + pBilldgv.Rows[i].Cells["pieceBuy"].Value.ToString() + "  where itmbar=" + pBilldgv.Rows[i].Cells["Item Barcode"].Value.ToString() + " ", cn);
                    cmd.ExecuteNonQuery();



                }
                MessageBox.Show("Saved successfully");
                this.Close();

                }


                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                cn.Close();
            }




        }

        private void pBillItemBartxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }


        }

        private void pBillItemNametxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }

        private void itemQuanttxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }

        private void itemPricetxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != '.' && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }

        private void pBillDatelbl_Click(object sender, EventArgs e)
        {

        }

        private void pBillItemBartxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void itemTtlPricetxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void pBilldgv_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pBillNolbl_Click(object sender, EventArgs e)
        {

        }

        private void itemExdatedtp_ValueChanged(object sender, EventArgs e)
        {

        }

        private void pBillTtlCostlbl_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pBillItemNametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void pBilldgv_ColumnAdded(object sender, DataGridViewColumnEventArgs e)
        {

        }

        private void pBilldgv_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {
            //pBilldgv.Columns["Item Barcode"].Visible = false;
        }

        private void pBilldgv_VisibleChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void PBillCompNamecmbo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                

                dt2.Clear();
                da2 = new SqlDataAdapter("select delId,delName from del where compId=" + PBillCompNamecmbo.SelectedValue + " ", cn);
                da2.Fill(dt2);
                pBillDelNamecmbo.DataSource = dt2;
                pBillDelNamecmbo.DisplayMember = "delname";
                pBillDelNamecmbo.ValueMember = "delid";

               

                 sdelid = Convert.ToString(pBillDelNamecmbo.SelectedValue);

                scompid =Convert.ToString( PBillCompNamecmbo.SelectedValue );

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void pBillEmpNametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void pBillCanclebtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pBilldgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectrow = e.RowIndex;
         DataGridViewRow   row = pBilldgv.Rows[selectrow];




         pBillItemBartxt.Text = row.Cells[0].Value.ToString();
         pBillItemNametxt.Text = row.Cells[1].Value.ToString();
         itemUnitcmbo.SelectedItem = row.Cells[2].Value.ToString();
         itemExdatedtp.Text = row.Cells[3].Value.ToString();
         itemQuanttxt.Text = row.Cells[4].Value.ToString();
         itemPricetxt.Text = row.Cells[5].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[6].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[7].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[8].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[9].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[10].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[11].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[12].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[13].Value.ToString();
         //pBillItemBartxt.Text = row.Cells[14].Value.ToString();


         //r[1] = pBillItemNametxt.Text;
         //r[2] = itemUnitcmbo.SelectedItem;

         //r[3] = aden;

         //r[4] = itemQuanttxt.Text;
         //r[5] = itemPricetxt.Text;
         //r[6] = itemTtlPricetxt.Text;
         //r[7] = packBP;
         //r[8] = tabBP;
         //r[9] = pillBP;
         //r[10] = pieceBP;
         //r[11] = packQuant;
         //r[12] = tabQuant;
         //r[13] = pillQuant;
         //r[14] = pieceQuant;


         //dt.Rows.Add(r);
         //pBilldgv.DataSource = dt;
         //clearItemsText();


        }

        private void pBillUpdateItembtn_Click(object sender, EventArgs e)
        {
            string aden = itemExdatedtp.Value.ToString("M/dd/yyyy");

            cmd = new SqlCommand("select pack,tab,pill,piece from item where itmbar='" + pBillItemBartxt.Text + "'", cn);

            cn.Open();
            dr = cmd.ExecuteReader();
            dr.Read();
            string pack;
            string tab;
            string pill;
            string piece;



            pack = dr["pack"].ToString();
            tab = dr["tab"].ToString();
            pill = dr["pill"].ToString();
            piece = dr["piece"].ToString();

            dr.Close();
            cn.Close();

            pBillItemNametxt.ReadOnly = false;
            pBillItemBartxt.ReadOnly = false;

            if (itemUnitcmbo.SelectedIndex == 0)
            {


                packBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pack)) / Convert.ToDouble(pack);
                tabBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(tab)) / Convert.ToDouble(pack);
                pillBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pill)) / Convert.ToDouble(pack);

                packQuant = (Convert.ToDouble(pack) / Convert.ToDouble(pack)) * Convert.ToInt32(itemQuanttxt.Text);
                tabQuant = (Convert.ToDouble(pack) / Convert.ToDouble(tab)) * Convert.ToInt32(itemQuanttxt.Text);
                pillQuant = (Convert.ToDouble(pack) / Convert.ToDouble(pill)) * Convert.ToInt32(itemQuanttxt.Text);


            }

            else if (itemUnitcmbo.SelectedIndex == 1)
            {


                packBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pack)) / Convert.ToDouble(tab);
                tabBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(tab)) / Convert.ToDouble(tab);
                pillBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pill)) / Convert.ToDouble(tab);

                packQuant = (Convert.ToDouble(tab) / Convert.ToDouble(pack)) * Convert.ToInt32(itemQuanttxt.Text);
                tabQuant = (Convert.ToDouble(tab) / Convert.ToDouble(tab)) * Convert.ToInt32(itemQuanttxt.Text);
                pillQuant = (Convert.ToDouble(tab) / Convert.ToDouble(pill)) * Convert.ToInt32(itemQuanttxt.Text);


            }

            else if (itemUnitcmbo.SelectedIndex == 2)
            {


                packBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pack)) / Convert.ToDouble(pill);
                tabBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(tab)) / Convert.ToDouble(pill);
                pillBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(pill)) / Convert.ToDouble(pill);

                packQuant = (Convert.ToDouble(pill) / Convert.ToDouble(pack)) * Convert.ToInt32(itemQuanttxt.Text);
                tabQuant = (Convert.ToDouble(pill) / Convert.ToDouble(tab)) * Convert.ToInt32(itemQuanttxt.Text);
                pillQuant = (Convert.ToDouble(pill) / Convert.ToDouble(pill)) * Convert.ToInt32(itemQuanttxt.Text);


            }
            else if (itemUnitcmbo.SelectedIndex == 3)
            {
                pieceBP = (Convert.ToDouble(itemPricetxt.Text) * Convert.ToDouble(piece)) / Convert.ToDouble(piece);

                pieceQuant = (Convert.ToDouble(piece) * Convert.ToInt32(itemQuanttxt.Text));


            }





           DataGridViewRow rowupdate =pBilldgv.Rows[selectrow];
           rowupdate.Cells[0].Value = pBillItemBartxt.Text;
           rowupdate.Cells[1].Value = pBillItemNametxt.Text;
           rowupdate.Cells[2].Value = itemUnitcmbo.SelectedItem;

           rowupdate.Cells[3].Value = aden;

           rowupdate.Cells[4].Value = itemQuanttxt.Text;
           rowupdate.Cells[5].Value = itemPricetxt.Text;
           rowupdate.Cells[6].Value = itemTtlPricetxt.Text;
           rowupdate.Cells[7].Value = packBP;
           rowupdate.Cells[8].Value = tabBP;
           rowupdate.Cells[9].Value = pillBP;
           rowupdate.Cells[10].Value = pieceBP;
           rowupdate.Cells[11].Value = packQuant;
           rowupdate.Cells[12].Value = tabQuant;
           rowupdate.Cells[13].Value = pillQuant;
           rowupdate.Cells[14].Value = pieceQuant;




           clearItemsText();
          

            pBillTtlCostlbl.Text = (from DataGridViewRow row in pBilldgv.Rows where row.Cells[6].FormattedValue.ToString() != string.Empty select Convert.ToDouble(row.Cells[6].FormattedValue)).Sum().ToString();

        }

        private void pBillDelletItembtn_Click(object sender, EventArgs e)
        {
            selectrow = pBilldgv.CurrentCell.RowIndex;
            pBilldgv.Rows.RemoveAt(selectrow);
            clearItemsText();
            pBillItemNametxt.ReadOnly = false;
            pBillItemBartxt.ReadOnly = false;
          
          
        }

        private void itemUnitcmbo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pBillItemBartxt_Leave(object sender, EventArgs e)
        {
            if (pBillItemBartxt.Text.Trim() != "")
            {
                cn.Open();
                cmd = new SqlCommand("select itmtrdname from item where itmBar =" + pBillItemBartxt.Text + " ", cn);

                dr5 = cmd.ExecuteReader();
                dr5.Read();
                pBillItemNametxt.Text = dr5["itmtrdname"].ToString();
                pBillItemNametxt.ReadOnly = true;
                cn.Close();
            }
           
            
        }

        private void pBillItemNametxt_Leave(object sender, EventArgs e)
        {
            if (pBillItemNametxt.Text.Trim() != "")
            {
                cn.Open();
                cmd = new SqlCommand("select itmBar from item where itmtrdname = '" + pBillItemNametxt.Text + "' ", cn);

                dr6 = cmd.ExecuteReader();
                dr6.Read();
                pBillItemBartxt.Text = dr6["itmBar"].ToString();

                pBillItemBartxt.ReadOnly = true;

                cn.Close();
            }
           
          
        }

        private void pBilldgv_SelectionChanged(object sender, EventArgs e)
        {
            pBillSavebtn.Enabled = pBilldgv.Rows.Count > 0;
        }

        private void pBillItemBartxt_MouseClick(object sender, MouseEventArgs e)
        {
        
        }

        private void pBillItemNametxt_MouseClick(object sender, MouseEventArgs e)
        {
          
        }

    }
}
