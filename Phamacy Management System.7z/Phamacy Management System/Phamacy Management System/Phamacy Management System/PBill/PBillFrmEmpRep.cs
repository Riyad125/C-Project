﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Phamacy_Management_System.PBill
{
    public partial class PBillFrmEmpRep : Form
    {

        SqlConnection cn = new SqlConnection("server=. ; database=pharmacy ; integrated security=true");
        public PBillFrmEmpRep()
        {
            InitializeComponent();
        }

        private void ComDateFrom_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PBillFrmEmpRep_Load(object sender, EventArgs e)
        {
            SqlCommand cm1 = new SqlCommand("select empname from emp", cn);

            cn.Open();
            SqlDataReader dr1 = cm1.ExecuteReader();
            while (dr1.Read())
            {
                ComEmpName.Items.Add(dr1["empname"]);

            }
            cn.Close();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da9 = new SqlDataAdapter("SELECT pBill.pBillNo, pBill.pBillDate, pBill.compName, pBill.delName,pBill.empname,pBill.ttlcost, pBillDet.itmBar, item.itmTrdName, pBillDet.itmUnit, pBillDet.exdate,pBillDet.quant, pBillDet.ttlPrice FROM  item INNER JOIN pBillDet ON item.itmBar = pBillDet.itmBar INNER JOIN pBill ON pBillDet.pBillNo = pBill.pBillNo WHERE pBill.empName = '" + ComEmpName.SelectedItem + "' ", cn);
            DataSet ds9 = new DataSet();
            da9.Fill(ds9, "item,pBillDet,pBill");

            PBill.PBillByNo obj = new PBill.PBillByNo();
            obj.SetDataSource(ds9.Tables["item,pBillDet,pBill"]);

            crystalReportViewer1.ReportSource = obj;
        }
    }
}
