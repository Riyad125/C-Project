﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Phamacy_Management_System
{
    public partial class PBillFrmToday : Form
    {
     
      

           
        public PBillFrmToday()
        {
            InitializeComponent();
           
        }

        private void PBillFrmToday_Load(object sender, EventArgs e)
        {

           string startdate = DateTime.Now.ToString("MM/dd/yyyy");


         //   label1.Text = DateTime.Now.ToString("MM/dd/yyyy");
     //    string startdate = DateTime.Now.ToString("MM/dd/yyyy 00:00:00");
       //     string enddate = DateTime.Now.ToString("MM/dd/yyyy 23:59:59");
            //string startdate ="2017-01-18 00:00:00.000";
            //string enddate = "2017-01-18 23:59:59.997";

           // label1.Text = startdate + enddate;

           //SqlDataAdapter da9 = new SqlDataAdapter("  SELECT pBill.pBillNo, pBill.pBillDate, pBill.compName, pBill.delName, pBill.ttlCost, pBillDet.itmBar, pBillDet.itmUnit, pBillDet.itmPrice, pBillDet.quant, pBillDet.ttlPrice, pBillDet.exdate, item.itmTrdNameFROM   (pharmacy.dbo.pBillDet pBillDet INNER JOIN pharmacy.dbo.pBill pBill ON pBillDet.pBillNo=pBill.pBillNo) INNER JOIN pharmacy.dbo.item item ON pBillDet.itmBar=item.itmBarORDER BY pBill.pBillNo" , cn);

           //   SqlDataAdapter da9 = new SqlDataAdapter("SELECT DISTINCT  pBill.pBillNo, pBill.pBillDate, pBill.compName,pBill.empName, pBill.delName,pBill.ttlcost, pBillDet.itmBar, item.itmTrdName, pBillDet.itmUnit, pBillDet.exdate,pBillDet.quant, pBillDet.ttlPrice FROM  item INNER JOIN pBillDet ON item.itmBar = pBillDet.itmBar INNER JOIN pBill ON pBillDet.pBillNo = pBill.pBillNo WHERE pBill.pBillDate between '" + startdate + "' AND '" + enddate + "'  ", cn);


            SqlConnection cn = new SqlConnection("server=. ; database=pharmacy ; integrated security=true");

 
            SqlDataAdapter da9 = new SqlDataAdapter("SELECT  pBill.pBillNo, pBill.pBillDate, pBill.compName,pBill.empName, pBill.delName,pBill.ttlcost, pBillDet.itmBar, item.itmTrdName, pBillDet.itmUnit, pBillDet.exdate,pBillDet.quant, pBillDet.ttlPrice FROM  item INNER JOIN pBillDet ON item.itmBar = pBillDet.itmBar INNER JOIN pBill ON pBillDet.pBillNo = pBill.pBillNo WHERE pBill.pBillDate like  '" + startdate + "%'   ", cn);



            DataSet ds9 = new DataSet();
            da9.Fill(ds9, "item,pBillDet,pBill");

            PBill.PBillByNo obj = new PBill.PBillByNo();
            obj.SetDataSource(ds9.Tables["item,pBillDet,pBill"]);

            crystalReportViewer1.ReportSource = obj;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
