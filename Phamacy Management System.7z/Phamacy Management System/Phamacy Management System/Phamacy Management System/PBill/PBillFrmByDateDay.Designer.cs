﻿namespace Phamacy_Management_System
{
    partial class PBillFrmByDateDay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.ComDateFrom = new System.Windows.Forms.ComboBox();
            this.ComDateTo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Left;
            this.crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(1194, 509);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // ComDateFrom
            // 
            this.ComDateFrom.FormattingEnabled = true;
            this.ComDateFrom.Location = new System.Drawing.Point(1200, 61);
            this.ComDateFrom.Name = "ComDateFrom";
            this.ComDateFrom.Size = new System.Drawing.Size(124, 21);
            this.ComDateFrom.TabIndex = 1;
            this.ComDateFrom.SelectedIndexChanged += new System.EventHandler(this.ComDateFrom_SelectedIndexChanged);
            // 
            // ComDateTo
            // 
            this.ComDateTo.FormattingEnabled = true;
            this.ComDateTo.Location = new System.Drawing.Point(1200, 100);
            this.ComDateTo.Name = "ComDateTo";
            this.ComDateTo.Size = new System.Drawing.Size(126, 21);
            this.ComDateTo.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1214, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Date Spcificatio";
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(1226, 140);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 6;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // PBillFrmByDateDay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 509);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ComDateTo);
            this.Controls.Add(this.ComDateFrom);
            this.Controls.Add(this.crystalReportViewer1);
            this.Name = "PBillFrmByDateDay";
            this.Text = "PBillFrmByDateDay";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.PBillFrmByDateDay_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private System.Windows.Forms.ComboBox ComDateFrom;
        private System.Windows.Forms.ComboBox ComDateTo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnsearch;
    }
}