﻿namespace Phamacy_Management_System
{
    partial class EditItemFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.editItemUpdatebtn = new System.Windows.Forms.Button();
            this.editItemCanclebtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.itemName = new System.Windows.Forms.TextBox();
            this.itemBarcode = new System.Windows.Forms.TextBox();
            this.itemShowInfobtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.addItemCompcomb = new System.Windows.Forms.ComboBox();
            this.addItemScNametxt = new System.Windows.Forms.TextBox();
            this.addItemBartxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.addItemTrdNametxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.addItemDelcomb = new System.Windows.Forms.ComboBox();
            this.addExDatedtp = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.sellDfltPiecerdb = new System.Windows.Forms.RadioButton();
            this.sellDfltPackrdb = new System.Windows.Forms.RadioButton();
            this.sellDfltTabrdb = new System.Windows.Forms.RadioButton();
            this.sellDfltPillrdb = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buyDfltPiecerdb = new System.Windows.Forms.RadioButton();
            this.buyDfltPackrdb = new System.Windows.Forms.RadioButton();
            this.buyDfltTabrdb = new System.Windows.Forms.RadioButton();
            this.buyDfltPillrdb = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pieceSPtxt = new System.Windows.Forms.TextBox();
            this.packSPtxt = new System.Windows.Forms.TextBox();
            this.tabSPtxt = new System.Windows.Forms.TextBox();
            this.pillSPtxt = new System.Windows.Forms.TextBox();
            this.pieceBPtxt = new System.Windows.Forms.TextBox();
            this.packBPtxt = new System.Windows.Forms.TextBox();
            this.tabBPtxt = new System.Windows.Forms.TextBox();
            this.pillBPtxt = new System.Windows.Forms.TextBox();
            this.piecenum = new System.Windows.Forms.NumericUpDown();
            this.packnum = new System.Windows.Forms.NumericUpDown();
            this.tabnum = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.pillnum = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.pieceQuanttxt = new System.Windows.Forms.TextBox();
            this.pillQuanttxt = new System.Windows.Forms.TextBox();
            this.tabQuanttxt = new System.Windows.Forms.TextBox();
            this.packQuanttxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piecenum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillnum)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // editItemUpdatebtn
            // 
            this.editItemUpdatebtn.BackColor = System.Drawing.Color.Teal;
            this.editItemUpdatebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editItemUpdatebtn.ForeColor = System.Drawing.Color.White;
            this.editItemUpdatebtn.Location = new System.Drawing.Point(282, 562);
            this.editItemUpdatebtn.Name = "editItemUpdatebtn";
            this.editItemUpdatebtn.Size = new System.Drawing.Size(94, 32);
            this.editItemUpdatebtn.TabIndex = 33;
            this.editItemUpdatebtn.Text = "Update";
            this.editItemUpdatebtn.UseVisualStyleBackColor = false;
            this.editItemUpdatebtn.Click += new System.EventHandler(this.editItemUpdatebtn_Click);
            // 
            // editItemCanclebtn
            // 
            this.editItemCanclebtn.BackColor = System.Drawing.Color.Teal;
            this.editItemCanclebtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.editItemCanclebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editItemCanclebtn.ForeColor = System.Drawing.Color.White;
            this.editItemCanclebtn.Location = new System.Drawing.Point(394, 562);
            this.editItemCanclebtn.Name = "editItemCanclebtn";
            this.editItemCanclebtn.Size = new System.Drawing.Size(94, 32);
            this.editItemCanclebtn.TabIndex = 34;
            this.editItemCanclebtn.Text = "Cancle";
            this.editItemCanclebtn.UseVisualStyleBackColor = false;
            this.editItemCanclebtn.Click += new System.EventHandler(this.editItemCanclebtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(26, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 16);
            this.label8.TabIndex = 38;
            this.label8.Text = "Enter Item Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Teal;
            this.label10.Location = new System.Drawing.Point(26, 59);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 16);
            this.label10.TabIndex = 39;
            this.label10.Text = "Enter Item Barcode";
            // 
            // itemName
            // 
            this.itemName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.itemName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.itemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemName.ForeColor = System.Drawing.Color.Black;
            this.itemName.Location = new System.Drawing.Point(174, 21);
            this.itemName.Name = "itemName";
            this.itemName.Size = new System.Drawing.Size(214, 22);
            this.itemName.TabIndex = 0;
            this.itemName.TextChanged += new System.EventHandler(this.showInfoBtnValidation);
            this.itemName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.itemName_KeyPress);
            this.itemName.Validating += new System.ComponentModel.CancelEventHandler(this.showInfoValidating);
            // 
            // itemBarcode
            // 
            this.itemBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemBarcode.ForeColor = System.Drawing.Color.Black;
            this.itemBarcode.Location = new System.Drawing.Point(174, 56);
            this.itemBarcode.Name = "itemBarcode";
            this.itemBarcode.Size = new System.Drawing.Size(214, 22);
            this.itemBarcode.TabIndex = 1;
            this.itemBarcode.TextChanged += new System.EventHandler(this.showInfoBtnValidation);
            this.itemBarcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.itemBarcode_KeyPress);
            this.itemBarcode.Validating += new System.ComponentModel.CancelEventHandler(this.showInfoValidating);
            // 
            // itemShowInfobtn
            // 
            this.itemShowInfobtn.BackColor = System.Drawing.Color.Teal;
            this.itemShowInfobtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemShowInfobtn.ForeColor = System.Drawing.Color.White;
            this.itemShowInfobtn.Location = new System.Drawing.Point(411, 34);
            this.itemShowInfobtn.Name = "itemShowInfobtn";
            this.itemShowInfobtn.Size = new System.Drawing.Size(111, 28);
            this.itemShowInfobtn.TabIndex = 2;
            this.itemShowInfobtn.Text = "Show info";
            this.itemShowInfobtn.UseVisualStyleBackColor = false;
            this.itemShowInfobtn.Click += new System.EventHandler(this.itemShowInfobtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.itemName);
            this.groupBox1.Controls.Add(this.itemShowInfobtn);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.itemBarcode);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.SeaGreen;
            this.groupBox1.Location = new System.Drawing.Point(166, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 89);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search Items";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.addItemCompcomb);
            this.groupBox5.Controls.Add(this.addItemScNametxt);
            this.groupBox5.Controls.Add(this.addItemBartxt);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.addItemTrdNametxt);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.addItemDelcomb);
            this.groupBox5.Controls.Add(this.addExDatedtp);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox5.ForeColor = System.Drawing.Color.SeaGreen;
            this.groupBox5.Location = new System.Drawing.Point(17, 133);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(798, 127);
            this.groupBox5.TabIndex = 44;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Item General Info";
            // 
            // addItemCompcomb
            // 
            this.addItemCompcomb.BackColor = System.Drawing.Color.Teal;
            this.addItemCompcomb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addItemCompcomb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addItemCompcomb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemCompcomb.ForeColor = System.Drawing.Color.White;
            this.addItemCompcomb.FormattingEnabled = true;
            this.addItemCompcomb.Location = new System.Drawing.Point(166, 89);
            this.addItemCompcomb.Name = "addItemCompcomb";
            this.addItemCompcomb.Size = new System.Drawing.Size(211, 24);
            this.addItemCompcomb.TabIndex = 7;
            this.addItemCompcomb.SelectedIndexChanged += new System.EventHandler(this.addItemCompcomb_SelectedIndexChanged);
            // 
            // addItemScNametxt
            // 
            this.addItemScNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemScNametxt.ForeColor = System.Drawing.Color.Black;
            this.addItemScNametxt.Location = new System.Drawing.Point(166, 57);
            this.addItemScNametxt.MaxLength = 40;
            this.addItemScNametxt.Name = "addItemScNametxt";
            this.addItemScNametxt.Size = new System.Drawing.Size(211, 22);
            this.addItemScNametxt.TabIndex = 5;
            this.addItemScNametxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addItemScNametxt_KeyPress);
            // 
            // addItemBartxt
            // 
            this.addItemBartxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemBartxt.ForeColor = System.Drawing.Color.Black;
            this.addItemBartxt.Location = new System.Drawing.Point(166, 23);
            this.addItemBartxt.Name = "addItemBartxt";
            this.addItemBartxt.Size = new System.Drawing.Size(211, 22);
            this.addItemBartxt.TabIndex = 3;
            this.addItemBartxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addItemBartxt_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(15, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "Company";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(15, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 16);
            this.label2.TabIndex = 24;
            this.label2.Text = "Item Scientfic Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(15, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Item Barcode";
            // 
            // addItemTrdNametxt
            // 
            this.addItemTrdNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemTrdNametxt.ForeColor = System.Drawing.Color.Black;
            this.addItemTrdNametxt.Location = new System.Drawing.Point(545, 23);
            this.addItemTrdNametxt.MaxLength = 40;
            this.addItemTrdNametxt.Name = "addItemTrdNametxt";
            this.addItemTrdNametxt.Size = new System.Drawing.Size(234, 22);
            this.addItemTrdNametxt.TabIndex = 4;
            this.addItemTrdNametxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addItemTrdNametxt_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(399, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Expire date";
            // 
            // addItemDelcomb
            // 
            this.addItemDelcomb.BackColor = System.Drawing.Color.Teal;
            this.addItemDelcomb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addItemDelcomb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addItemDelcomb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemDelcomb.ForeColor = System.Drawing.Color.White;
            this.addItemDelcomb.FormattingEnabled = true;
            this.addItemDelcomb.Location = new System.Drawing.Point(545, 92);
            this.addItemDelcomb.Name = "addItemDelcomb";
            this.addItemDelcomb.Size = new System.Drawing.Size(234, 24);
            this.addItemDelcomb.TabIndex = 8;
            this.addItemDelcomb.SelectedIndexChanged += new System.EventHandler(this.addItemDelcomb_SelectedIndexChanged);
            // 
            // addExDatedtp
            // 
            this.addExDatedtp.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addExDatedtp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addExDatedtp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.addExDatedtp.Location = new System.Drawing.Point(545, 53);
            this.addExDatedtp.Name = "addExDatedtp";
            this.addExDatedtp.Size = new System.Drawing.Size(234, 22);
            this.addExDatedtp.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(399, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "Delegate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(399, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 16);
            this.label1.TabIndex = 19;
            this.label1.Text = "Item Trading Name";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.pieceSPtxt);
            this.groupBox2.Controls.Add(this.packSPtxt);
            this.groupBox2.Controls.Add(this.tabSPtxt);
            this.groupBox2.Controls.Add(this.pillSPtxt);
            this.groupBox2.Controls.Add(this.pieceBPtxt);
            this.groupBox2.Controls.Add(this.packBPtxt);
            this.groupBox2.Controls.Add(this.tabBPtxt);
            this.groupBox2.Controls.Add(this.pillBPtxt);
            this.groupBox2.Controls.Add(this.piecenum);
            this.groupBox2.Controls.Add(this.packnum);
            this.groupBox2.Controls.Add(this.tabnum);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.pillnum);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox2.ForeColor = System.Drawing.Color.SeaGreen;
            this.groupBox2.Location = new System.Drawing.Point(31, 265);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(764, 196);
            this.groupBox2.TabIndex = 45;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Price Details";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.sellDfltPiecerdb);
            this.groupBox4.Controls.Add(this.sellDfltPackrdb);
            this.groupBox4.Controls.Add(this.sellDfltTabrdb);
            this.groupBox4.Controls.Add(this.sellDfltPillrdb);
            this.groupBox4.Location = new System.Drawing.Point(660, 45);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(68, 144);
            this.groupBox4.TabIndex = 56;
            this.groupBox4.TabStop = false;
            // 
            // sellDfltPiecerdb
            // 
            this.sellDfltPiecerdb.AutoSize = true;
            this.sellDfltPiecerdb.Location = new System.Drawing.Point(27, 121);
            this.sellDfltPiecerdb.Name = "sellDfltPiecerdb";
            this.sellDfltPiecerdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltPiecerdb.TabIndex = 28;
            this.sellDfltPiecerdb.UseVisualStyleBackColor = true;
            // 
            // sellDfltPackrdb
            // 
            this.sellDfltPackrdb.AutoSize = true;
            this.sellDfltPackrdb.Checked = true;
            this.sellDfltPackrdb.Location = new System.Drawing.Point(27, 86);
            this.sellDfltPackrdb.Name = "sellDfltPackrdb";
            this.sellDfltPackrdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltPackrdb.TabIndex = 27;
            this.sellDfltPackrdb.TabStop = true;
            this.sellDfltPackrdb.UseVisualStyleBackColor = true;
            // 
            // sellDfltTabrdb
            // 
            this.sellDfltTabrdb.AutoSize = true;
            this.sellDfltTabrdb.Location = new System.Drawing.Point(27, 48);
            this.sellDfltTabrdb.Name = "sellDfltTabrdb";
            this.sellDfltTabrdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltTabrdb.TabIndex = 26;
            this.sellDfltTabrdb.UseVisualStyleBackColor = true;
            // 
            // sellDfltPillrdb
            // 
            this.sellDfltPillrdb.AutoSize = true;
            this.sellDfltPillrdb.Location = new System.Drawing.Point(27, 18);
            this.sellDfltPillrdb.Name = "sellDfltPillrdb";
            this.sellDfltPillrdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltPillrdb.TabIndex = 25;
            this.sellDfltPillrdb.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buyDfltPiecerdb);
            this.groupBox3.Controls.Add(this.buyDfltPackrdb);
            this.groupBox3.Controls.Add(this.buyDfltTabrdb);
            this.groupBox3.Controls.Add(this.buyDfltPillrdb);
            this.groupBox3.Location = new System.Drawing.Point(539, 45);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(73, 144);
            this.groupBox3.TabIndex = 55;
            this.groupBox3.TabStop = false;
            // 
            // buyDfltPiecerdb
            // 
            this.buyDfltPiecerdb.AutoSize = true;
            this.buyDfltPiecerdb.Location = new System.Drawing.Point(29, 121);
            this.buyDfltPiecerdb.Name = "buyDfltPiecerdb";
            this.buyDfltPiecerdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltPiecerdb.TabIndex = 24;
            this.buyDfltPiecerdb.UseVisualStyleBackColor = true;
            // 
            // buyDfltPackrdb
            // 
            this.buyDfltPackrdb.AutoSize = true;
            this.buyDfltPackrdb.Checked = true;
            this.buyDfltPackrdb.Location = new System.Drawing.Point(29, 86);
            this.buyDfltPackrdb.Name = "buyDfltPackrdb";
            this.buyDfltPackrdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltPackrdb.TabIndex = 23;
            this.buyDfltPackrdb.TabStop = true;
            this.buyDfltPackrdb.UseVisualStyleBackColor = true;
            // 
            // buyDfltTabrdb
            // 
            this.buyDfltTabrdb.AutoSize = true;
            this.buyDfltTabrdb.Location = new System.Drawing.Point(29, 48);
            this.buyDfltTabrdb.Name = "buyDfltTabrdb";
            this.buyDfltTabrdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltTabrdb.TabIndex = 22;
            this.buyDfltTabrdb.UseVisualStyleBackColor = true;
            // 
            // buyDfltPillrdb
            // 
            this.buyDfltPillrdb.AutoSize = true;
            this.buyDfltPillrdb.Location = new System.Drawing.Point(29, 18);
            this.buyDfltPillrdb.Name = "buyDfltPillrdb";
            this.buyDfltPillrdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltPillrdb.TabIndex = 21;
            this.buyDfltPillrdb.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(639, 25);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(127, 20);
            this.label20.TabIndex = 54;
            this.label20.Text = "Selling Default";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(521, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(127, 20);
            this.label19.TabIndex = 53;
            this.label19.Text = "Buying Default";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(377, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 20);
            this.label18.TabIndex = 52;
            this.label18.Text = "Selling Price";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(236, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(108, 20);
            this.label17.TabIndex = 51;
            this.label17.Text = "Buying Price";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(91, 25);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 20);
            this.label16.TabIndex = 50;
            this.label16.Text = "Number of pieces";
            // 
            // pieceSPtxt
            // 
            this.pieceSPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pieceSPtxt.ForeColor = System.Drawing.Color.Black;
            this.pieceSPtxt.Location = new System.Drawing.Point(374, 166);
            this.pieceSPtxt.Name = "pieceSPtxt";
            this.pieceSPtxt.Size = new System.Drawing.Size(100, 22);
            this.pieceSPtxt.TabIndex = 20;
            this.pieceSPtxt.Text = "0";
            this.pieceSPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pieceSPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // packSPtxt
            // 
            this.packSPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packSPtxt.ForeColor = System.Drawing.Color.Black;
            this.packSPtxt.Location = new System.Drawing.Point(374, 131);
            this.packSPtxt.Name = "packSPtxt";
            this.packSPtxt.Size = new System.Drawing.Size(100, 22);
            this.packSPtxt.TabIndex = 19;
            this.packSPtxt.Text = "0";
            this.packSPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.packSPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // tabSPtxt
            // 
            this.tabSPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSPtxt.ForeColor = System.Drawing.Color.Black;
            this.tabSPtxt.Location = new System.Drawing.Point(374, 93);
            this.tabSPtxt.Name = "tabSPtxt";
            this.tabSPtxt.Size = new System.Drawing.Size(100, 22);
            this.tabSPtxt.TabIndex = 18;
            this.tabSPtxt.Text = "0";
            this.tabSPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tabSPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // pillSPtxt
            // 
            this.pillSPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pillSPtxt.ForeColor = System.Drawing.Color.Black;
            this.pillSPtxt.Location = new System.Drawing.Point(374, 52);
            this.pillSPtxt.Name = "pillSPtxt";
            this.pillSPtxt.Size = new System.Drawing.Size(100, 22);
            this.pillSPtxt.TabIndex = 17;
            this.pillSPtxt.Text = "0";
            this.pillSPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pillSPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // pieceBPtxt
            // 
            this.pieceBPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pieceBPtxt.ForeColor = System.Drawing.Color.Black;
            this.pieceBPtxt.Location = new System.Drawing.Point(233, 166);
            this.pieceBPtxt.Name = "pieceBPtxt";
            this.pieceBPtxt.Size = new System.Drawing.Size(100, 22);
            this.pieceBPtxt.TabIndex = 16;
            this.pieceBPtxt.Text = "0";
            this.pieceBPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pieceBPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // packBPtxt
            // 
            this.packBPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packBPtxt.ForeColor = System.Drawing.Color.Black;
            this.packBPtxt.Location = new System.Drawing.Point(233, 131);
            this.packBPtxt.Name = "packBPtxt";
            this.packBPtxt.Size = new System.Drawing.Size(100, 22);
            this.packBPtxt.TabIndex = 15;
            this.packBPtxt.Text = "0";
            this.packBPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.packBPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // tabBPtxt
            // 
            this.tabBPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabBPtxt.ForeColor = System.Drawing.Color.Black;
            this.tabBPtxt.Location = new System.Drawing.Point(232, 92);
            this.tabBPtxt.Name = "tabBPtxt";
            this.tabBPtxt.Size = new System.Drawing.Size(100, 22);
            this.tabBPtxt.TabIndex = 14;
            this.tabBPtxt.Text = "0";
            this.tabBPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tabBPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // pillBPtxt
            // 
            this.pillBPtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pillBPtxt.ForeColor = System.Drawing.Color.Black;
            this.pillBPtxt.Location = new System.Drawing.Point(233, 56);
            this.pillBPtxt.Name = "pillBPtxt";
            this.pillBPtxt.Size = new System.Drawing.Size(100, 22);
            this.pillBPtxt.TabIndex = 13;
            this.pillBPtxt.Text = "0";
            this.pillBPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pillBPtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // piecenum
            // 
            this.piecenum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piecenum.ForeColor = System.Drawing.Color.Black;
            this.piecenum.Location = new System.Drawing.Point(104, 167);
            this.piecenum.Name = "piecenum";
            this.piecenum.Size = new System.Drawing.Size(63, 22);
            this.piecenum.TabIndex = 12;
            this.piecenum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // packnum
            // 
            this.packnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packnum.ForeColor = System.Drawing.Color.Black;
            this.packnum.Location = new System.Drawing.Point(104, 131);
            this.packnum.Name = "packnum";
            this.packnum.Size = new System.Drawing.Size(63, 22);
            this.packnum.TabIndex = 11;
            this.packnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabnum
            // 
            this.tabnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabnum.ForeColor = System.Drawing.Color.Black;
            this.tabnum.Location = new System.Drawing.Point(103, 93);
            this.tabnum.Name = "tabnum";
            this.tabnum.Size = new System.Drawing.Size(63, 22);
            this.tabnum.TabIndex = 10;
            this.tabnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Teal;
            this.label15.Location = new System.Drawing.Point(23, 169);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 16);
            this.label15.TabIndex = 30;
            this.label15.Text = "Piece";
            // 
            // pillnum
            // 
            this.pillnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pillnum.ForeColor = System.Drawing.Color.Black;
            this.pillnum.Location = new System.Drawing.Point(104, 57);
            this.pillnum.Name = "pillnum";
            this.pillnum.Size = new System.Drawing.Size(63, 22);
            this.pillnum.TabIndex = 9;
            this.pillnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Teal;
            this.label12.Location = new System.Drawing.Point(23, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 16);
            this.label12.TabIndex = 26;
            this.label12.Text = "Pill";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Teal;
            this.label14.Location = new System.Drawing.Point(22, 133);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 16);
            this.label14.TabIndex = 28;
            this.label14.Text = "Packet";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "Unit";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Teal;
            this.label13.Location = new System.Drawing.Point(22, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 16);
            this.label13.TabIndex = 27;
            this.label13.Text = "Table";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.pieceQuanttxt);
            this.groupBox6.Controls.Add(this.pillQuanttxt);
            this.groupBox6.Controls.Add(this.tabQuanttxt);
            this.groupBox6.Controls.Add(this.packQuanttxt);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox6.ForeColor = System.Drawing.Color.SeaGreen;
            this.groupBox6.Location = new System.Drawing.Point(93, 468);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(643, 84);
            this.groupBox6.TabIndex = 46;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Quantity of item";
            // 
            // pieceQuanttxt
            // 
            this.pieceQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pieceQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.pieceQuanttxt.Location = new System.Drawing.Point(441, 60);
            this.pieceQuanttxt.Name = "pieceQuanttxt";
            this.pieceQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.pieceQuanttxt.TabIndex = 32;
            this.pieceQuanttxt.Text = "0";
            this.pieceQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pieceQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // pillQuanttxt
            // 
            this.pillQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pillQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.pillQuanttxt.Location = new System.Drawing.Point(441, 21);
            this.pillQuanttxt.Name = "pillQuanttxt";
            this.pillQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.pillQuanttxt.TabIndex = 31;
            this.pillQuanttxt.Text = "0";
            this.pillQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pillQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // tabQuanttxt
            // 
            this.tabQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.tabQuanttxt.Location = new System.Drawing.Point(164, 60);
            this.tabQuanttxt.Name = "tabQuanttxt";
            this.tabQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.tabQuanttxt.TabIndex = 30;
            this.tabQuanttxt.Text = "0";
            this.tabQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tabQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // packQuanttxt
            // 
            this.packQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.packQuanttxt.Location = new System.Drawing.Point(164, 21);
            this.packQuanttxt.Name = "packQuanttxt";
            this.packQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.packQuanttxt.TabIndex = 29;
            this.packQuanttxt.Text = "0";
            this.packQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.packQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(378, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "Piece";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(378, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Pill";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.Color.Teal;
            this.label21.Location = new System.Drawing.Point(105, 63);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 16);
            this.label21.TabIndex = 1;
            this.label21.Text = "Table";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.Teal;
            this.label22.Location = new System.Drawing.Point(105, 24);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 16);
            this.label22.TabIndex = 0;
            this.label22.Text = "Packet";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label23.ForeColor = System.Drawing.Color.Teal;
            this.label23.Location = new System.Drawing.Point(385, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(101, 24);
            this.label23.TabIndex = 47;
            this.label23.Text = "Edit Items";
            // 
            // EditItemFrm
            // 
            this.AcceptButton = this.itemShowInfobtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.CancelButton = this.editItemCanclebtn;
            this.ClientSize = new System.Drawing.Size(905, 600);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.editItemCanclebtn);
            this.Controls.Add(this.editItemUpdatebtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditItemFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Items";
            this.Load += new System.EventHandler(this.EditItemFrm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piecenum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillnum)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button editItemUpdatebtn;
        private System.Windows.Forms.Button editItemCanclebtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox itemName;
        private System.Windows.Forms.TextBox itemBarcode;
        private System.Windows.Forms.Button itemShowInfobtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox addItemTrdNametxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox addItemDelcomb;
        private System.Windows.Forms.DateTimePicker addExDatedtp;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox addItemCompcomb;
        private System.Windows.Forms.TextBox addItemScNametxt;
        private System.Windows.Forms.TextBox addItemBartxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton sellDfltPiecerdb;
        private System.Windows.Forms.RadioButton sellDfltPackrdb;
        private System.Windows.Forms.RadioButton sellDfltTabrdb;
        private System.Windows.Forms.RadioButton sellDfltPillrdb;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton buyDfltPiecerdb;
        private System.Windows.Forms.RadioButton buyDfltPackrdb;
        private System.Windows.Forms.RadioButton buyDfltTabrdb;
        private System.Windows.Forms.RadioButton buyDfltPillrdb;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox pieceSPtxt;
        private System.Windows.Forms.TextBox packSPtxt;
        private System.Windows.Forms.TextBox tabSPtxt;
        private System.Windows.Forms.TextBox pillSPtxt;
        private System.Windows.Forms.TextBox pieceBPtxt;
        private System.Windows.Forms.TextBox packBPtxt;
        private System.Windows.Forms.TextBox tabBPtxt;
        private System.Windows.Forms.TextBox pillBPtxt;
        private System.Windows.Forms.NumericUpDown piecenum;
        private System.Windows.Forms.NumericUpDown packnum;
        private System.Windows.Forms.NumericUpDown tabnum;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown pillnum;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox pieceQuanttxt;
        private System.Windows.Forms.TextBox pillQuanttxt;
        private System.Windows.Forms.TextBox tabQuanttxt;
        private System.Windows.Forms.TextBox packQuanttxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
    }
}