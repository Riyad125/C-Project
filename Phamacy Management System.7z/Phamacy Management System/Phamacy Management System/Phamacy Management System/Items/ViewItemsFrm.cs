﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Phamacy_Management_System
{
    public partial class ViewItemsFrm : Form
    {
        SqlConnection cn = new SqlConnection("server=. ; database=pharmacy ; integrated security=true");
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        public ViewItemsFrm()
        {
            InitializeComponent();
            //this.viewItemsdgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //da = new SqlDataAdapter("select itmBar as Barcode,itmTrdName as 'Trading name' ,itmScName as 'Scintfic name',pack as 'Pills in packet',tab as 'Pills in table',exdate as 'Expire date',packQuant as 'Packet quantity',tabQuant as 'Table quantity' from item where buyDflt !='buyDfltPiecerdb'", cn);
            //da.Fill(dt);
            //viewItemsdgv.DataSource = dt;
        }

        private void ViewItemsFrm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pharmacyDataSet2.item' table. You can move, or remove it, as needed.
            this.itemTableAdapter.Fill(this.pharmacyDataSet2.item);
            //// TODO: This line of code loads data into the 'pharmacyDataSet2.item' table. You can move, or remove it, as needed.
            //this.itemTableAdapter.Fill(this.pharmacyDataSet2.item);
            //this.viewItemsdgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            //comboBox1.Items.Add("Packet");
            //comboBox1.Items.Add("Piece");
            //comboBox1.SelectedItem = "Packet";
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if(comboBox1.SelectedIndex==0)
            //{
            //    viewItemsdgv.DataSource = null;
            //    viewItemsdgv.Rows.Clear();
            //    viewItemsdgv.Columns.Clear();
            //    dt.Columns.Clear();
            //    dt.Clear();
            //    da = new SqlDataAdapter("select itmBar as Barcode,itmTrdName as 'Trading name' ,itmScName as 'Scintfic name',pack as 'Pills in packet',tab as 'Pills in table',exdate as 'Expire date',packQuant as 'Packet quantity',tabQuant as 'Table quantity' from item where buyDflt !='buyDfltPiecerdb'", cn);
            //    da.Fill(dt);
            //    viewItemsdgv.DataSource = dt;
            //}
            //if (comboBox1.SelectedIndex == 1)
            //{
            //    viewItemsdgv.DataSource = null;
            //    viewItemsdgv.Rows.Clear();
            //    viewItemsdgv.Columns.Clear();
            //    dt.Columns.Clear();
            //    dt.Clear();
            //    da = new SqlDataAdapter("select itmBar as Barcode,itmTrdName as 'Trading name' ,pieceQuant as 'Pieces quantity',exdate as 'Expire date' from item where buyDflt='buyDfltPiecerdb'", cn);
            //    da.Fill(dt);
            //    viewItemsdgv.DataSource = dt;
            //}
        }

        private void itemBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //this.Validate();
            //this.itemBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.pharmacyDataSet2);

        }

        private void itemBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.itemBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pharmacyDataSet2);

        }

        private void itemDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
